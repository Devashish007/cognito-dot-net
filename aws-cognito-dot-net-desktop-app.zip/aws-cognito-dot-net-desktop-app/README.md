This is a sample for showing the Cognito dot net implementation for the user management. For the details related to implementation, please refer https://sid343.reinvent-workshop.com/

